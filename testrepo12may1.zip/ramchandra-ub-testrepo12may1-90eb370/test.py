import os
import sys

current_dir = os.getcwd()

print(current_dir)